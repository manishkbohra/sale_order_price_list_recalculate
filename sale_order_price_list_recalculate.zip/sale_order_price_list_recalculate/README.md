---------------------------------
sale_order_price_list_recalcualte
---------------------------------


This module add onchange method on sale order:

* Order line recalculation according to the customer and price list using onchange method.

It is launched manually as a button to get the user decide if he/she wants to
recalculate prices when pricelist is changed or after duplicating a sale order
to update or not sales information.

**Table of contents**

Installation:
-------------

There are two depended module sale and sale_management for accessing the needed for the actions.

Usage:
------

In the sale order, you can onchange customer and price list to recalculation 
of your order line and losing the previous custom prices in the order line.

Authors:
--------
* Manish Kumar Bohra

Developer:
----------
* Manish Kumar Bohra <manishbohra1994@gmail.com> or <manishkumarbohra@outlook.com>

